﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Shell;

namespace WpfApp1
{
    public class UserContol1VM : ViewModelBase
    {
        private bool isPopup;

        public ESViewControl ESViewControl { get; set; }
        private Window _window;
        private ContentControl _contentcontrol;

        public RelayCommand<ContentControl> Command => new RelayCommand<ContentControl>(contentcontrol =>
        {
            if (_contentcontrol == null)
            {
                _contentcontrol = contentcontrol;
            }
            IsPopup = true;
            _contentcontrol.Content = null;
            _window = new Window() { Height = 300, Width = 500, WindowStartupLocation = WindowStartupLocation.CenterScreen };
            WindowChrome.SetWindowChrome(_window, new WindowChrome());
            _window.Content = ESViewControl;
            ESViewControl.DataContext = this;
            _window.Show();
        }, contentcontrol => IsPopup == false);

        public RelayCommand BackCommand => new RelayCommand(() =>
        {
            IsPopup = false;
            _window.Content = null;
            _window.Close();
            _contentcontrol.Content = ESViewControl;
        });

        public bool IsPopup
        {
            get => isPopup; set
            {
                Set(ref isPopup, value);
                Command.RaiseCanExecuteChanged();
            }
        }
        public UserContol1VM()
        {
            ESViewControl = new ESViewControl();
        }
    }
}
