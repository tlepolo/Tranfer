﻿using GalaSoft.MvvmLight.Command;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace WpfApp1
{
    public class MainViewModel
    {
        public UserContol1VM UserContol1VM { get; set; } = new UserContol1VM();
        public List<MyTabItem> Tabs { get; set; }

       

        public MainViewModel()
        {
            Tabs = new List<MyTabItem>()
           {
            new MyTabItem { Header="1",UserControl=new UserControl1(){ DataContext=UserContol1VM} },
            new MyTabItem { Header="2",UserControl=new UserControl2()},
          };
        }

    }

    public class MyTabItem
    {
        public string Header { get; set; }
        public UserControl UserControl { get; set; }
    }
}
