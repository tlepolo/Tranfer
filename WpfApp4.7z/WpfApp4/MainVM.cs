﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp4
{
    internal class MainVM
    {
        public ObservableCollection<Person> Persons { get; set; }

        public MainVM()
        {
            Persons = new ObservableCollection<Person>();
            for (int i = 0; i < 10; i++)
            {
                Person person = new Person();
                person.Age = i;
                person.Name = "person" + i;
                Persons.Add(person);
            }
        }
    }
}
