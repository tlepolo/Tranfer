﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp4
{
    public class Person : INotifyPropertyChanged
    {
        private string _name;
        private int _age;

        public string Name
        {
            get { return _name; }
            set
            {
                _name = value;
                NotifyPropertyChanged("Name");
            }
        }

        public int Age
        {
            get { return _age; }
            set
            {
                _age = value;
                NotifyPropertyChanged("Age");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public void NotifyPropertyChanged(string name)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(name));
        }

        public List<Clothing> Clothings { get; set; } = new List<Clothing>()
        {
            new Clothing{Name="aa",Price=101.11},
            new Clothing{Name="bb",Price=102.11},
            new Clothing{Name="cc",Price=103.11},
            new Clothing{Name="dd",Price=104.11},
            new Clothing{Name="ee",Price=104.11},
        };

    }

    public class Clothing
    {
        public string Name { get; set; }
        public double Price { get; set; }
    }
}
