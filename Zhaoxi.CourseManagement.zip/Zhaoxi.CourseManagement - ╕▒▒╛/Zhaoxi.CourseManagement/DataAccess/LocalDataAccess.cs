﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zhaoxi.CourseManagement.Common;
using Zhaoxi.CourseManagement.DataAccess.DataEnties;
using Zhaoxi.CourseManagement.Models;

namespace Zhaoxi.CourseManagement.DataAccess
{
    public class LocalDataAccess
    {
        private static LocalDataAccess instance;

        private LocalDataAccess() { }


        public static LocalDataAccess GetInstance()
        {
            return instance ?? (instance = new LocalDataAccess());
        }

        SqlConnection conn;
        SqlCommand comm;
        SqlDataAdapter adapter;

        private void Dispose()
        {
            adapter?.Dispose();
            comm?.Dispose();
            conn?.Dispose();
        }


        private bool DBConnection()
        {
            string connStr = ConfigurationManager.ConnectionStrings["mssql"].ConnectionString;
            if (conn == null || this.conn.ConnectionString == "")
            {
                conn = new SqlConnection(connStr);
            }
            try
            {
                conn.Open();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public UserEntity CheckUserInfo(string username, string pwd)
        {
            try
            {
                if (DBConnection())
                {
                    string sql = "select * from users where user_name=@username and password=@pwd and is_validation=1";
                    adapter = new SqlDataAdapter(sql, conn);
                    adapter.SelectCommand.Parameters.Add(new SqlParameter("@username", username));
                    adapter.SelectCommand.Parameters.Add(new SqlParameter("@pwd", MD5Provider.GetMD5String(pwd + "@" + username)));
                    DataTable dataTable = new DataTable();
                    int count = adapter.Fill(dataTable);
                    if (count == 0)
                    {
                        throw new Exception("用户名或密码不正确");
                    }
                    DataRow dr = dataTable.Rows[0];
                    if (dr.Field<Int32>("is_can_login") == 0)
                    {
                        throw new Exception("当前用户没有权限使用此平台");
                    }
                    UserEntity userEntity = new UserEntity();
                    userEntity.UserName = dr.Field<string>("user_name");
                    userEntity.RealName = dr.Field<string>("real_name");
                    userEntity.Password = dr.Field<string>("password");
                    userEntity.Avator = dr.Field<string>("avatar");
                    userEntity.Gender = dr.Field<int>("gender");
                    return userEntity;
                }
                return null;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                this.Dispose();
            }
        }

        public List<CourseModel> GetCourses()
        {
            try
            {
                List<CourseModel> result = new List<CourseModel>();
                if (this.DBConnection())
                {
                    string sql = @"select a.course_id,a.course_name,a.course_cover,a.course_url,a.description,c.real_name from courses a left join course_teacher_relation b on a.course_id=b.course_id left join users c on b.teacher_id=c.user_id order by a.course_id";
                    adapter = new SqlDataAdapter(sql, conn);
                    DataTable table = new DataTable();
                    int count = adapter.Fill(table);
                    if (count > 0)
                    {
                        string courseid = "";
                        CourseModel model = null;
                        foreach (DataRow dataRow in table.AsEnumerable())
                        {
                            string tempid = dataRow.Field<string>("course_id");
                            if (courseid != tempid)
                            {
                                courseid = tempid;
                                model = new CourseModel
                                {
                                    CourseName = dataRow.Field<string>("course_name"),
                                    Cover = dataRow.Field<string>("course_cover"),
                                    Url = dataRow.Field<string>("course_url"),
                                    Description = dataRow.Field<string>("description"),
                                    Teachers = new List<string>()
                                };

                                result.Add(model);
                            }
                            if (model != null)
                            {
                                model.Teachers.Add(dataRow.Field<string>("real_name"));
                            }
                        }
                    }
                }
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                this.Dispose();
            }
        }
    }
}
