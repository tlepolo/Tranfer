﻿using LiveCharts;
using LiveCharts.Defaults;
using LiveCharts.Wpf;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zhaoxi.CourseManagement.Common;
using Zhaoxi.CourseManagement.Models;

namespace Zhaoxi.CourseManagement.ViewModels
{
    public class FirstPageViewModel : NotifyBase
    {

        public ObservableCollection<CourseSeriesModel> CourseSeriesList { get; set; }


        public FirstPageViewModel()
        {
            CourseSeriesList = new ObservableCollection<CourseSeriesModel>()
            {
                new CourseSeriesModel()
                {
                    CourseName="java" ,
                    SeriesCollection=new LiveCharts.SeriesCollection()
                    {
                    new PieSeries{ Title="zhaoxi1",Values=new ChartValues<ObservableValue>{ new ObservableValue(123)},DataLabels=false },
                    new PieSeries{ Title="zhaoxi2",Values=new ChartValues<ObservableValue>{ new ObservableValue(234)},DataLabels=false },
                    },
                    SeriesList=new ObservableCollection<SeriesModel>()
                    {
                        new SeriesModel{SeriesName="云课堂1",CurrentValue=160,IsGrowing=false,ChangeRate=75},
                        new SeriesModel{SeriesName="云课堂2",CurrentValue=160,IsGrowing=true,ChangeRate=75},
                        new SeriesModel{SeriesName="云课堂3",CurrentValue=160,IsGrowing=false,ChangeRate=75},
                        new SeriesModel{SeriesName="云课堂4",CurrentValue=160,IsGrowing=true,ChangeRate=75},
                        new SeriesModel{SeriesName="云课堂5",CurrentValue=160,IsGrowing=false,ChangeRate=75},
                    }
                },
                new CourseSeriesModel()
                {
                    CourseName="java" ,
                    SeriesCollection=new LiveCharts.SeriesCollection()
                    {
                    new PieSeries{ Title="zhaoxi1",Values=new ChartValues<ObservableValue>{ new ObservableValue(123)},DataLabels=false },
                    new PieSeries{ Title="zhaoxi2",Values=new ChartValues<ObservableValue>{ new ObservableValue(234)},DataLabels=false },
                    },
                    SeriesList=new ObservableCollection<SeriesModel>()
                    {
                        new SeriesModel{SeriesName="云课堂1",CurrentValue=160,IsGrowing=false,ChangeRate=75},
                        new SeriesModel{SeriesName="云课堂2",CurrentValue=160,IsGrowing=true,ChangeRate=75},
                        new SeriesModel{SeriesName="云课堂3",CurrentValue=160,IsGrowing=false,ChangeRate=75},
                        new SeriesModel{SeriesName="云课堂4",CurrentValue=160,IsGrowing=true,ChangeRate=75},
                        new SeriesModel{SeriesName="云课堂5",CurrentValue=160,IsGrowing=false,ChangeRate=75},
                    }
                },
                new CourseSeriesModel()
                {
                    CourseName="java" ,
                    SeriesCollection=new LiveCharts.SeriesCollection()
                    {
                    new PieSeries{ Title="zhaoxi1",Values=new ChartValues<ObservableValue>{ new ObservableValue(123)},DataLabels=false },
                    new PieSeries{ Title="zhaoxi2",Values=new ChartValues<ObservableValue>{ new ObservableValue(234)},DataLabels=false },
                    },
                    SeriesList=new ObservableCollection<SeriesModel>()
                    {
                        new SeriesModel{SeriesName="云课堂1",CurrentValue=160,IsGrowing=false,ChangeRate=75},
                        new SeriesModel{SeriesName="云课堂2",CurrentValue=160,IsGrowing=true,ChangeRate=75},
                        new SeriesModel{SeriesName="云课堂3",CurrentValue=160,IsGrowing=false,ChangeRate=75},
                        new SeriesModel{SeriesName="云课堂4",CurrentValue=160,IsGrowing=true,ChangeRate=75},
                        new SeriesModel{SeriesName="云课堂5",CurrentValue=160,IsGrowing=false,ChangeRate=75},
                    }
                },
            };
        }
    }
}
