﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Zhaoxi.CourseManagement.Common;
using Zhaoxi.CourseManagement.Models;

namespace Zhaoxi.CourseManagement.ViewModels
{
    public class MainViewModel : NotifyBase
    {
        private string searchText;
        private FrameworkElement mainContent;

        public UserModel UserInfo { get; set; }

        public string SearchText
        {
            get { return searchText; }
            set
            {
                searchText = value;
                this.DoNotify();
            }
        }

        public CommandBase NavChangedComand { get; set; }


        public FrameworkElement MainContent
        {
            get => mainContent;
            set
            {
                mainContent = value;
                this.DoNotify();
            }
        }

        public MainViewModel()
        {
            this.UserInfo = new UserModel();
            this.UserInfo.Avator = GlobalValues.UserInfo?.Avator;
            this.UserInfo.UserName = GlobalValues.UserInfo?.UserName;
            this.UserInfo.Gender = (int)(GlobalValues.UserInfo?.Gender);
            NavChangedComand = new CommandBase();
            NavChangedComand.DoExecute += new Action<object>(DoNavChange);
            NavChangedComand.DoCanExecute += new Func<object, bool>(o => true);

            DoNavChange("FirstPageView");
        }

        private void DoNavChange(object obj)
        {
            Type type = Type.GetType("Zhaoxi.CourseManagement.Views." + obj);
            FrameworkElement frameworkElement = Activator.CreateInstance(type) as FrameworkElement;
            this.MainContent = frameworkElement;
        }
    }
}
