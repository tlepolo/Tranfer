﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Zhaoxi.CourseManagement.Common;
using Zhaoxi.CourseManagement.DataAccess;
using Zhaoxi.CourseManagement.Models;

namespace Zhaoxi.CourseManagement.ViewModels
{
    public class LoginViewModel : NotifyBase
    {
        private string errorMsg;
        private Visibility showProgress = Visibility.Collapsed;

        public CommandBase CloseButtonCommand { get; set; }
        public LoginModel LoginModel { get; set; }
        public CommandBase LoginCommand { get; set; }

        public string ErrorMessage
        {
            get => errorMsg; set
            {
                errorMsg = value;
                DoNotify();
            }
        }

        public Visibility ShowProgress
        {
            get => showProgress; set
            {
                showProgress = value;
                DoNotify();
                LoginCommand.RaiseCanExecuteChanged();
            }
        }

        public LoginViewModel()
        {
            LoginModel = new LoginModel();
            CloseButtonCommand = new CommandBase();
            CloseButtonCommand.DoExecute = obj =>
            {
                ((Window)obj).Close();
            };
            CloseButtonCommand.DoCanExecute = obj => true;
            this.LoginCommand = new CommandBase();
            this.LoginCommand.DoExecute = new Action<object>(DoLogin);
            this.LoginCommand.DoCanExecute = new Func<object, bool>(obj => showProgress == Visibility.Collapsed);

        }

        private void DoLogin(object obj)
        {
            this.ErrorMessage = null;
            if (string.IsNullOrEmpty(LoginModel.UserName))
            {
                this.ErrorMessage = "用户名不能为空";
                return;
            }
            if (string.IsNullOrEmpty(LoginModel.Password))
            {
                this.ErrorMessage = "密码不能为空";
                return;
            }
            if (string.IsNullOrEmpty(LoginModel.ValidationCode))
            {
                this.ErrorMessage = "验证码不能为空";
                return;
            }
            this.ShowProgress = Visibility.Visible;
            Task.Run(async () =>
            {
                try
                {
                    await Task.Delay(10);
                    var user = LocalDataAccess.GetInstance().CheckUserInfo(LoginModel.UserName, LoginModel.Password);
                    if (user == null)
                    {
                        throw new Exception("登录失败！用户名或密码错误");
                    }
                    GlobalValues.UserInfo = user;
                    Application.Current.Dispatcher.Invoke(() =>
                    {
                        Window window = obj as Window;
                        window.DialogResult = true;
                    });
                }
                catch (Exception ex)
                {
                    this.ErrorMessage = ex.Message;
                }
                finally
                {
                    Application.Current.Dispatcher.Invoke(new Action(() =>
                 {
                     this.ShowProgress = Visibility.Collapsed;
                 }));
                }
            });


        }
    }
}
