﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zhaoxi.CourseManagement.DataAccess.DataEnties;

namespace Zhaoxi.CourseManagement.Common
{
    public class GlobalValues
    {
        public static UserEntity UserInfo { get; set; } = new UserEntity();
    }
}
