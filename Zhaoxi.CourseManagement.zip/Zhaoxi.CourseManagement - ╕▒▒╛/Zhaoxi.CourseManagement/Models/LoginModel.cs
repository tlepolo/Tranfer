﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zhaoxi.CourseManagement.Common;

namespace Zhaoxi.CourseManagement.Models
{
    public class LoginModel : NotifyBase
    {
        private string username;

        public string UserName
        {
            get { return username; }
            set
            {
                username = value;
                this.DoNotify();
            }
        }

        private string password;

        public string Password
        {
            get { return password; }
            set
            {
                password = value;
                this.DoNotify();
            }
        }


        private string validationcode;

        public string ValidationCode
        {
            get { return validationcode; }
            set
            {
                validationcode = value;
                this.DoNotify();
            }
        }


    }
}
