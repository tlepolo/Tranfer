﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zhaoxi.CourseManagement.Models
{
    public class CategoryItemModel
    {
        public CategoryItemModel()
        {

        }

        public CategoryItemModel(string categoryName, bool isSelected = false)
        {
            IsSelected = isSelected;
            CategoryName = categoryName;
        }

        public bool IsSelected { get; set; }
        public string CategoryName { get; set; }
    }
}
