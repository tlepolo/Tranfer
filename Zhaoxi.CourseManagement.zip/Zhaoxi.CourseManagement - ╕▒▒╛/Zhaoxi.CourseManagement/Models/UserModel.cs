﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zhaoxi.CourseManagement.Common;

namespace Zhaoxi.CourseManagement.Models
{
    public class UserModel : NotifyBase
    {
        private string avator;
        private int age;

        public string Avator
        {
            get { return avator; }
            set
            {
                avator = value;
                this.DoNotify();
            }
        }

        public int Age
        {
            get => age; set
            {
                age = value;
                this.DoNotify();
            }
        }

        private string username;

        public string UserName
        {
            get { return username; }
            set
            {
                username = value;
                this.DoNotify();
            }
        }

        private int gender;

        public int Gender
        {
            get { return gender; }
            set
            {
                gender = value;
                this.DoNotify();
            }
        }



    }
}
