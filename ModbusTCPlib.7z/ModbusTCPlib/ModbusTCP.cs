﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace ModbusTCPlib
{
    public class ModbusTCP
    {
        private Socket tcpClient = null;

        public string IPAddress { get; set; }
        public int Port { get; set; }

        public byte SlaveId { get; set; } = 0x01;

        public ModbusTCP(string ip, int port)
        {
            this.IPAddress = ip;
            this.Port = port;
        }

        public bool Connect()
        {
            tcpClient = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                tcpClient.Connect(System.Net.IPAddress.Parse(IPAddress), Port);

            }
            catch (Exception)
            {
                return false;
            }
            return true;
        }

        public void DisConnect()
        {
            if (tcpClient != null)
            {
                tcpClient.Close();
            }
        }


        public ushort[] ReadHoldingRegisters(ushort start, ushort length)
        {
            //拼接报文
            List<byte> rqst = new List<byte>();
            rqst.Add(0x00);  //trans
            rqst.Add(0x00);
            rqst.Add(0x00);  //protocol
            rqst.Add(0x00);
            rqst.AddRange(new byte[] { 0, 6 }); //长度
            rqst.Add(SlaveId);
            rqst.Add(0x03);  //function
            rqst.Add((byte)(start / 256)); //index
            rqst.Add((byte)(start % 256));
            rqst.Add((byte)(length / 256)); //length
            rqst.Add((byte)(length % 256));
            //发送报文
            tcpClient.Send(rqst.ToArray());
            //接收报文
            byte[] buffer = new byte[1024];
            int cnt = tcpClient.Receive(buffer);
            //验证报文
            if (cnt == 2 * length + 9)
            {
                byte[] des = new byte[cnt];
                Array.Copy(buffer, 0, des, 0, cnt);
                if (des[6] == SlaveId && des[7] == 0x03 && des[8] == 2 * length)
                {
                    //解析报文
                    byte[] res = new byte[2 * length];
                    Array.Copy(des, 9, res, 0, 2 * length);
                    List<ushort> result = new List<ushort>();
                    for (int i = 0; i < res.Length; i += 2)
                    {
                        result.Add(Convert.ToUInt16(res[i] * 256 + res[i + 1]));
                    }
                    return result.ToArray();
                }
            }
            return null;
        }
    }
}
