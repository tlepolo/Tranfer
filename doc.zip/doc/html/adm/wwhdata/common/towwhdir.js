function  WWHToWWHelpDirectory()
{
  return "../";
}
